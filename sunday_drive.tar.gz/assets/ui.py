from settings import *

class UI:
    '''Class for the display in the game'''
    def __init__(self):
        self.font = pygame.font.Font(asset_path('graphics','fonts','Jersey10-Regular.ttf'),30)

        self.score_display = self.font.render('0',True,colors['Blue'])
        self.highscore_display = self.font.render('0',True,colors['Blue'])
        self.background_rect = pygame.Rect(25,25,180,50)

        self.screen = pygame.display.get_surface()

    def update(self,score,highscore):
        self.score_display = self.font.render('Score: '+str(round(score,2)),True,colors['Blue'])
        self.highscore_display = self.font.render('Highscore: '+str(round(highscore,2)),True,colors['Blue'])

    def draw(self):
        pygame.draw.rect(self.screen,(127,127,127),self.background_rect,border_radius=5)
        self.screen.blit(self.score_display,(30,20))
        self.screen.blit(self.highscore_display,(30,45))


class Menu:
    def __init__(self):
        self.font80 = pygame.font.Font(asset_path('graphics','fonts','Jersey10-Regular.ttf'),80)
        self.font45 = pygame.font.Font(asset_path('graphics','fonts','Jersey10-Regular.ttf'),45)

        self.sign = pygame.transform.scale(pygame.image.load(asset_path('graphics','road','signs','gidgames.png')).convert_alpha(), (60,80))
        self.sign = pygame.transform.rotate(self.sign, 8)

        self.background = pygame.transform.scale(pygame.image.load(asset_path('graphics','road','road','road.png')).convert(), (WIDTH, HEIGHT))
        self.title_display = self.font80.render('SUNDAY DRIVE',True,colors['Blue'])
        self.start_display = self.font45.render('Press any key to start',True,colors['Red'])

        self.screen = pygame.display.get_surface()

    def draw(self):
        self.screen.blit(self.background, (0, 0))
        self.screen.blit(self.sign,(WIDTH-self.sign.get_width(),HEIGHT//2-self.sign.get_height()//3))
        self.screen.blit(self.title_display,(WIDTH//2-self.title_display.get_width()//2,HEIGHT//2-100))
        self.screen.blit(self.start_display,(WIDTH//2-self.start_display.get_width()//2,HEIGHT//2+100))

