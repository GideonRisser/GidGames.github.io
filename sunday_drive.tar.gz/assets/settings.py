from pathlib import Path
import pygame, random, sys, asyncio
random.seed()

BASE_DIR = Path(__file__).resolve().parent


def asset_path(*parts):
    return str(BASE_DIR.joinpath(*parts))

# Screen
WIDTH = 400
HEIGHT = 800
caption = 'Sunday Drive'

# Accessability
tickrate = 60 #fps
carspeed = 250

# Resources
colors = {
    'Blue': (0,0,255),
    'Red': (255,0,0),
    'Green': (0,255,0),
}
lanes = [100, 200, 300]
signs = ['deer_crossing', 'gidgames', 'limit_10', 'wrong_way']
