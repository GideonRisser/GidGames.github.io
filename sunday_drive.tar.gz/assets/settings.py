import pygame, random, sys, asyncio
from support import import_folder
random.seed()

# Screen
WIDTH = 400
HEIGHT = 800
caption = 'Sunday Drive'

# Accessability
tickrate = 60 #fps
carspeed = 250

# Resources
colors = {
    'Blue': (0,0,255),
    'Red': (255,0,0),
    'Green': (0,255,0),
}
lanes = [100, 200, 300]
