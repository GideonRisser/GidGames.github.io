from settings import *

class Obstacle:
    def __init__(self,lane,surf):
        self.image = surf
        self.rect = self.image.get_frect(midbottom = (lanes[lane],0))

        self.screen = pygame.display.get_surface()

    def update(self, speed, dt):
        self.rect.y += speed * dt

    def draw(self):
        self.screen.blit(self.image,self.rect)

class Truck(Obstacle):
    def __init__(self, lane):
        surf = pygame.transform.scale(pygame.image.load(asset_path('graphics','cars','purple_truck.png')).convert_alpha(),(50,200))
        surf = pygame.transform.rotate(surf,180)
        super().__init__(lane, surf)

class Car(Obstacle):
    def __init__(self, lane):
        surf = pygame.transform.scale(pygame.image.load(asset_path('graphics','cars','green_car.png')).convert_alpha(),(50,100))
        surf = pygame.transform.rotate(surf,180)
        super().__init__(lane, surf)

class Deer:
    def __init__(self):
        self.load_animation()

        self.rect = self.image.get_frect(topleft = (WIDTH, 0))

        self.speed = random.randint(50, 300)

        self.screen = pygame.display.get_surface()

    def load_animation(self):
        self.animation_surfs = [
            pygame.transform.scale(pygame.image.load(asset_path('graphics','obstacles','deer','deer_1.png')).convert_alpha(),(84,70)),
            pygame.transform.scale(pygame.image.load(asset_path('graphics','obstacles','deer','deer_2.png')).convert_alpha(),(84,70))
        ]
        self.animation_index = 0
        self.image = self.animation_surfs[self.animation_index]

    def animate(self, dt):
        self.animation_index += 5 * dt
        if self.animation_index >= len(self.animation_surfs):
            self.animation_index = 0
        self.image = self.animation_surfs[int(self.animation_index)]

    def update(self, speed, dt):
        self.rect.x -= self.speed * dt
        self.rect.y += speed * dt / 2
        self.animate(dt)

    def draw(self):
        self.screen.blit(self.image, self.rect)