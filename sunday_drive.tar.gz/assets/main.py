from settings import *
from player import Player
from cars import *
from ui import UI, Menu
from road import Road

class Game:
    def __init__(self):
        # Window setup
        pygame.init()
        random.seed()
        self.screen = pygame.display.set_mode((WIDTH,HEIGHT))
        pygame.display.set_caption(caption)
        # Tool setup
        self.clock = pygame.time.Clock()

        # Game variables
        self.speed = 200

        # Randomness
        self.carspawntimer = 0

        # Scoring
        self.score = 0
        self.highscore = 0

        # Game setup
        self.menu = Menu()
        self.ui = UI()
        self.background = Road()
        self.player = Player((WIDTH//2, HEIGHT-50))
        self.cars = []

    def restart(self):
        self.speed = 200
        self.carspawntimer = 0
        self.score = 0

        self.player = Player((WIDTH//2, HEIGHT-50))
        self.cars = []

    def keepscore(self, dt):
        self.score += dt
        if self.score >= self.highscore:
            self.highscore = self.score

    def check_car_collisions(self,newcar):
        not_touching = True
        for car in self.cars:
            if newcar.rect.colliderect(car.rect):
                not_touching = False
        return not_touching

    def create_cars(self, dt):
        self.carspawntimer += dt
        if self.carspawntimer > 2 and random.randint(1,3) == 1:
            self.carspawntimer = 0
            match random.randint(1,20):
                case 1 | 2 | 3 | 4 | 5:
                    new_car = Truck(random.randint(0,2))
                    if self.check_car_collisions(new_car):
                        self.cars.append(new_car)
                case 6:
                    new_deer = Deer()
                    if self.check_car_collisions(new_deer):
                        self.cars.append(new_deer)
                case _:
                    new_car = Car(random.randint(0,2))
                    if self.check_car_collisions(new_car):
                        self.cars.append(new_car)

    def check_for_loss(self):
        for car in self.cars:
            if self.player.rect.colliderect(car.rect):
                self.restart()

    def update(self, dt):
        self.background.update(self.speed, dt)
        self.create_cars(dt)
        for car in self.cars:
            car.update(self.speed, dt)
            if car.rect.top > HEIGHT or car.rect.right < 0:
                self.cars.remove(car)
        self.player.update(dt, self.fingers)
        self.check_for_loss()
        self.ui.update(self.score,self.highscore)

        self.keepscore(dt)
        self.speed = 200 + self.score * 4 if self.score <= 200 else 1000

    def draw(self):
        self.screen.fill((127,127,127))
        self.background.draw1()
        self.player.draw()
        for car in self.cars:
            car.draw()
        self.background.draw2()
        self.ui.draw()

    async def main_menu(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN or event.type == pygame.FINGERDOWN or event.type == pygame.MOUSEBUTTONDOWN:
                    await self.run()

            self.menu.draw()

            self.clock.tick(tickrate)
            pygame.display.update()
            await asyncio.sleep(0)

    async def run(self):
        self.running = True
        self.fingers = {}
        self.restart()
        while self.running:
            dt = self.clock.tick(tickrate) / 1000
            mouse_pos = pygame.mouse.get_pos()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                if event.type == pygame.FINGERDOWN:
                    self.fingers[event.finger_id] = (event.x * WIDTH, event.y * HEIGHT)
                if event.type == pygame.FINGERUP:
                    if event.finger_id in self.fingers:
                        del self.fingers[event.finger_id]
                if event.type == pygame.FINGERMOTION:
                    if event.finger_id in self.fingers:
                        self.fingers[event.finger_id] = (event.x * WIDTH, event.y * HEIGHT)
                if event.type == pygame.MOUSEBUTTONDOWN:
                    self.fingers[999999] = mouse_pos
                if event.type == pygame.MOUSEMOTION:
                    if 999999 in self.fingers:
                        self.fingers[999999] = mouse_pos
                if event.type == pygame.MOUSEBUTTONUP:
                    if 999999 in self.fingers:
                        del self.fingers[999999]

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self.running = False

            self.update(dt)
            self.draw()

            pygame.display.update()
            await asyncio.sleep(0)

game = Game()
if __name__ == '__main__':
    asyncio.run(game.main_menu())
