from settings import *
from os import walk

def import_folder(path, scale = None):
    surface_list = []

    for _, __, files in walk(path):
        for file in files:
            surface = pygame.image.load(f'{path}/{file}').convert_alpha()
            if scale:
                surface = pygame.transform.scale(surface, scale)
            surface_list.append(surface)

    return surface_list
