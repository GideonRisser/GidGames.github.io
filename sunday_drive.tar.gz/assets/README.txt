Pygbag publish note:
- The game code is now using project-relative asset paths so it can run correctly when packaged.
- If the browser preview still shows a loading screen, the remaining blocker is pygbag's CDN runtime host. For publishing, use a local static server or a deployment target that can serve the generated build directory and its linked assets.
- The generated build is in build/web.
