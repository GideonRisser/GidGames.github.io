from settings import *

class Player:
    def __init__(self,pos):
        self.image = pygame.transform.scale(pygame.image.load(r'graphics\cars\player.png').convert_alpha(),(50, 100))
        self.rect = self.image.get_frect(midbottom=pos)

        # animation
        self.turning = False
        self.animation_timer = 0
        self.lane_index = 1  # Start in the middle lane_index (index 1)
        self.target_x = self.rect.x

        # touch regions
        self.touch_left = pygame.Rect(0, 0, WIDTH // 2, HEIGHT)
        self.touch_right = pygame.Rect(WIDTH // 2, 0, WIDTH // 2, HEIGHT)

        self.screen = pygame.display.get_surface()

    def input(self, fingers):
        # Handle keyboard input for lane changes
        keys = pygame.key.get_pressed()
        if (keys[pygame.K_LEFT] or keys[pygame.K_a]) and not self.turning:
            self.lane_index = self.lane_index - 1
            if self.lane_index < 0:
                self.lane_index = 0
            else:
                self.target_x = lanes[self.lane_index] - self.image.get_width() // 2
                self.turning = True
        elif (keys[pygame.K_RIGHT] or keys[pygame.K_d]) and not self.turning:
            self.lane_index = self.lane_index + 1
            if self.lane_index > len(lanes) - 1:
                self.lane_index = len(lanes) - 1
            else:
                self.target_x = lanes[self.lane_index] - self.image.get_width() // 2
                self.turning = True

        # Handle touch input for lane changes
        for finger_id, (x, y) in fingers.items():
            if self.touch_left.collidepoint(x, y) and not self.turning:
                self.lane_index = self.lane_index - 1
                if self.lane_index < 0:
                    self.lane_index = 0
                else:
                    self.target_x = lanes[self.lane_index] - self.image.get_width() // 2
                    self.turning = True
            elif self.touch_right.collidepoint(x, y) and not self.turning:
                self.lane_index = self.lane_index + 1
                if self.lane_index > len(lanes) - 1:
                    self.lane_index = len(lanes) - 1
                else:
                    self.target_x = lanes[self.lane_index] - self.image.get_width() // 2
                    self.turning = True

    def animate(self, dt):
        if self.turning:
            if self.rect.x < self.target_x:
                self.rect.x += carspeed * dt
                if self.rect.x >= self.target_x:
                    self.rect.x = self.target_x
                    self.turning = False
            elif self.rect.x > self.target_x:
                self.rect.x -= carspeed * dt
                if self.rect.x <= self.target_x:
                    self.rect.x = self.target_x
                    self.turning = False
        
    def update(self, dt, fingers):
        self.input(fingers)
        self.animate(dt)

    def draw(self):
        self.screen.blit(self.image, self.rect)