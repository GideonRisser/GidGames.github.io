from settings import *

class Sign:
    ''' Class for road signs '''
    def __init__(self, pos, img):
        self.image = pygame.transform.scale(img, (60, 80))
        self.image = pygame.transform.rotate(self.image, 8)
        self.rect = self.image.get_rect(bottomright=pos)

        self.screen = pygame.display.get_surface()

    def update(self, y):
        if y > self.rect.bottom:
            self.rect.bottom = y
        elif y < self.rect.bottom:
            self.rect.bottom = HEIGHT + y

    def draw(self):
        self.screen.blit(self.image, self.rect)



class Road:
    ''' Class for the road '''
    def __init__(self):
        self.image = pygame.transform.scale(pygame.image.load(r'graphics\road\road\road.png').convert(), (WIDTH, HEIGHT))
        self.y = 0
        self.sign_surfaces = import_folder('graphics/road/signs')
        self.signs = []

        self.screen = pygame.display.get_surface()

    def update(self, speed, dt):
        self.y += speed / 2 * dt
        if self.y >= HEIGHT:
            self.y = 0
            if random.randint(1, 10) == 1:
                self.signs.append(Sign((WIDTH, 0), random.choice(self.sign_surfaces)))
        for sign in self.signs:
            sign.update(self.y)
            if sign.rect.y > HEIGHT:
                self.signs.remove(sign)

    def draw1(self):
        self.screen.blit(self.image, (0, self.y))
        self.screen.blit(self.image, (0, self.y - HEIGHT))

    def draw2(self):
        for sign in self.signs:
            sign.draw()